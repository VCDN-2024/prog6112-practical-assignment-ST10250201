/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112_assignment.java;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
class StudentManagementSystem {
    
    String StudentName;
    String StudentCourse;
    int StudentAge; 
    String StudentEmail;
    String StudentID;

    ArrayList<String> arrayNameList = new ArrayList<>();
    ArrayList<String> arrayStudentID = new ArrayList<>();
    ArrayList<Integer> arrayStudentAge = new ArrayList<>();
    ArrayList<String> arrayStudentEmail = new ArrayList<>();
    ArrayList<String> arrayStudentCourse = new ArrayList<>();

    public void InsertStudent() {
        StudentID = JOptionPane.showInputDialog("Enter Student ID number");
        StudentName = JOptionPane.showInputDialog("Enter Student Name");
        StudentAge = Integer.parseInt(JOptionPane.showInputDialog("Enter Student Age"));
        StudentEmail = JOptionPane.showInputDialog("Enter Student email address");
        StudentCourse = JOptionPane.showInputDialog("Enter Student Course");

        arrayStudentID.add(StudentID);
        arrayNameList.add(StudentName);
        arrayStudentAge.add(StudentAge);
        arrayStudentEmail.add(StudentEmail);
        arrayStudentCourse.add(StudentCourse);
    }

    public void SearchStudent() {
        StudentID = JOptionPane.showInputDialog("Enter student ID to search");
        for (int i = 0; i < arrayStudentID.size(); i++) {
            if (StudentID.equals(arrayStudentID.get(i))) {
                JOptionPane.showMessageDialog(null,
                    "Student ID: " + arrayStudentID.get(i) + "\n" +
                    "Name: " + arrayNameList.get(i) + "\n" +
                    "Age: " + arrayStudentAge.get(i) + "\n" +
                    "Email: " + arrayStudentEmail.get(i) + "\n" +
                    "Course: " + arrayStudentCourse.get(i));
            }
        }
    }

    public void Menu() {
        int option = 0;
        do {
            option = Integer.parseInt(JOptionPane.showInputDialog(
                "Enter (1) to launch menu.\n" +
                "1) Add student.\n" +
                "2) Search Student.\n" +
                "3) Delete Student.\n" +
                "4) Print Student.\n" +
                "5) Exit"));

            switch (option) {
                case 1:
                    InsertStudent();
                    break;
                case 2:
                    SearchStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    printStudent();
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, "Exiting Program...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        } while (option != 5);
    }

    public void deleteStudent() {
        StudentID = JOptionPane.showInputDialog("Enter student ID that you would like to delete");
        for (int i = 0; i < arrayStudentID.size(); i++) {
            if (StudentID.equals(arrayStudentID.get(i))) {
                arrayStudentID.remove(i);
                arrayNameList.remove(i);
                arrayStudentAge.remove(i);
                arrayStudentEmail.remove(i);
                arrayStudentCourse.remove(i);
                JOptionPane.showMessageDialog(null, "Student " + StudentID + " deleted");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Student ID not found");
    }

    public void printStudent() {
        for (int i = 0; i < arrayStudentID.size(); i++) {
            JOptionPane.showMessageDialog(null,
                "Student ID: " + arrayStudentID.get(i) + "\n" +
                "Name: " + arrayNameList.get(i) + "\n" +
                "Age: " + arrayStudentAge.get(i) + "\n" +
                "Email: " + arrayStudentEmail.get(i) + "\n" +
                "Course: " + arrayStudentCourse.get(i));
        }
    }
}


