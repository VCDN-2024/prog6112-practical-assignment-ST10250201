/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog6112_assignment.java;
import javax.swing.*;


public class Prog6112_AssignmentJava {

    /**
     * @param args the command line arguments
     */
   
       public static void main(String[] args) {
        StudentManagementSystem student = new StudentManagementSystem();
        student.Menu();
    }
    
}
