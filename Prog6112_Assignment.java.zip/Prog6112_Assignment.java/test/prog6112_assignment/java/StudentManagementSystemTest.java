/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package prog6112_assignment.java;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class StudentManagementSystemTest {
    
    public StudentManagementSystemTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of InsertStudent method, of class StudentManagementSystem.
     */
    @Test
    public void testInsertStudent() {
        System.out.println("InsertStudent");
        StudentManagementSystem instance = new StudentManagementSystem();
        instance.InsertStudent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SearchStudent method, of class StudentManagementSystem.
     */
    @Test
    public void testSearchStudent() {
        System.out.println("SearchStudent");
        StudentManagementSystem instance = new StudentManagementSystem();
        instance.SearchStudent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Menu method, of class StudentManagementSystem.
     */
    @Test
    public void testMenu() {
        System.out.println("Menu");
        StudentManagementSystem instance = new StudentManagementSystem();
        instance.Menu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteStudent method, of class StudentManagementSystem.
     */
    @Test
    public void testDeleteStudent() {
        System.out.println("deleteStudent");
        StudentManagementSystem instance = new StudentManagementSystem();
        instance.deleteStudent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printStudent method, of class StudentManagementSystem.
     */
    @Test
    public void testPrintStudent() {
        System.out.println("printStudent");
        StudentManagementSystem instance = new StudentManagementSystem();
        instance.printStudent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
